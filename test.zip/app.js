console.log("ระบบจัดการสวนทุเรียนเริ่มทำงาน...");

// ตัวอย่างการแจ้งเตือน
function showAlert(message) {
  alert(message);
}